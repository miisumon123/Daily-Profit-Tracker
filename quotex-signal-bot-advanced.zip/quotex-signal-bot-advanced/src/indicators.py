
import numpy as np
import pandas as pd

def ema(series: pd.Series, span: int) -> pd.Series:
    return series.ewm(span=span, adjust=False).mean()

def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    delta = series.diff()
    gain = np.where(delta > 0, delta, 0.0)
    loss = np.where(delta < 0, -delta, 0.0)
    roll_up = pd.Series(gain, index=series.index).rolling(window=period).mean()
    roll_down = pd.Series(loss, index=series.index).rolling(window=period).mean()
    rs = roll_up / (roll_down + 1e-12)
    out = 100.0 - (100.0 / (1.0 + rs))
    return out

def bollinger_bands(series: pd.Series, period: int = 20, num_std: float = 2.0):
    ma = series.rolling(window=period).mean()
    std = series.rolling(window=period).std(ddof=0)
    upper = ma + num_std * std
    lower = ma - num_std * std
    return ma, upper, lower

def macd(series: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9):
    fast_ema = ema(series, fast)
    slow_ema = ema(series, slow)
    macd_line = fast_ema - slow_ema
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    hist = macd_line - signal_line
    return macd_line, signal_line, hist

def stoch_rsi(series: pd.Series, period: int = 14, k: int = 3, d: int = 3):
    # 1) compute RSI first
    r = rsi(series, period)
    # 2) rolling min/max of RSI
    min_r = r.rolling(window=period).min()
    max_r = r.rolling(window=period).max()
    stoch = (r - min_r) / (max_r - min_r + 1e-12) * 100.0
    k_line = stoch.rolling(window=k).mean()
    d_line = k_line.rolling(window=d).mean()
    return k_line, d_line
