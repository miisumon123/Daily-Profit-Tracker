
import pandas as pd
from ..indicators import rsi, ema, bollinger_bands, macd, stochastic_rsi

def score_row(row) -> int:
    score = 0
    # RSI
    if row["rsi"] < 30: score += 1
    if row["rsi"] > 70: score -= 1
    # EMA(20/50)
    if row["ema20"] > row["ema50"]: score += 1
    if row["ema20"] < row["ema50"]: score -= 1
    # Bollinger
    if row["close"] <= row["bb_lower"]: score += 1
    if row["close"] >= row["bb_upper"]: score -= 1
    # MACD
    if row["macd"] > row["macd_signal"]: score += 1
    if row["macd"] < row["macd_signal"]: score -= 1
    # Stochastic RSI
    if row["stoch_k"] < 20: score += 1
    if row["stoch_k"] > 80: score -= 1
    return score

def decide(score: int) -> tuple[str, int]:
    if score >= 3:
        return "CALL", int(abs(score) / 5 * 100)
    if score <= -3:
        return "PUT", int(abs(score) / 5 * 100)
    return "NO_TRADE", int(abs(score) / 5 * 100)

def build_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["ema20"] = ema(out["close"], 20)
    out["ema50"] = ema(out["close"], 50)
    out["rsi"] = rsi(out["close"], 14)
    ma, up, lo = bollinger_bands(out["close"], 20, 2.0)
    out["bb_ma"], out["bb_upper"], out["bb_lower"] = ma, up, lo
    macd_line, macd_signal, hist = macd(out["close"], 12, 26, 9)
    out["macd"], out["macd_signal"], out["macd_hist"] = macd_line, macd_signal, hist
    k_line, d_line = stochastic_rsi(out["close"], 14, 3, 3)
    out["stoch_k"], out["stoch_d"] = k_line, d_line

    out["score"] = out.apply(score_row, axis=1)
    signal, conf = zip(*out["score"].apply(decide))
    out["signal"] = signal
    out["confidence"] = conf
    return out

def latest_signal(df: pd.DataFrame) -> dict:
    row = df.dropna().iloc[-1].to_dict()
    return {
        "close": float(row["close"]),
        "signal": row["signal"],
        "confidence": int(row["confidence"]),
        "score": int(row["score"]),
        "rsi": float(row["rsi"]),
        "ema20": float(row["ema20"]),
        "ema50": float(row["ema50"]),
        "bb_upper": float(row["bb_upper"]),
        "bb_lower": float(row["bb_lower"]),
        "macd": float(row["macd"]),
        "macd_signal": float(row["macd_signal"]),
        "stoch_k": float(row["stoch_k"]),
        "stoch_d": float(row["stoch_d"]),
    }
