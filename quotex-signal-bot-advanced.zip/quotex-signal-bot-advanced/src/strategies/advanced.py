
import pandas as pd
from ..indicators import rsi, ema, bollinger_bands, macd, stoch_rsi

def score_row(row) -> int:
    score = 0
    # RSI
    if row["rsi"] < 30: score += 1
    if row["rsi"] > 70: score -= 1
    # EMA(20/50) trend
    if row["ema20"] > row["ema50"]: score += 1
    if row["ema20"] < row["ema50"]: score -= 1
    # Bollinger
    if row["close"] <= row["bb_lower"]: score += 1
    if row["close"] >= row["bb_upper"]: score -= 1
    # MACD
    if row["macd_line"] > row["macd_signal"]: score += 1
    if row["macd_line"] < row["macd_signal"]: score -= 1
    # Stoch RSI
    if row["stoch_k"] < 20: score += 1
    if row["stoch_k"] > 80: score -= 1
    return score

def decide(score: int) -> tuple[str, int]:
    if score >= 3:
        return "CALL", int(abs(score) / 5 * 100)
    if score <= -3:
        return "PUT", int(abs(score) / 5 * 100)
    return "NO_TRADE", int(abs(score) / 5 * 100)

def build_features(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["ema20"] = ema(out["close"], 20)
    out["ema50"] = ema(out["close"], 50)
    out["rsi"] = rsi(out["close"], 14)
    ma, up, lo = bollinger_bands(out["close"], 20, 2.0)
    out["bb_ma"], out["bb_upper"], out["bb_lower"] = ma, up, lo
    macd_line, macd_signal, macd_hist = macd(out["close"], 12, 26, 9)
    out["macd_line"], out["macd_signal"], out["macd_hist"] = macd_line, macd_signal, macd_hist
    stoch_k, stoch_d = stoch_rsi(out["close"], 14, 3, 3)
    out["stoch_k"], out["stoch_d"] = stoch_k, stoch_d

    out["score"] = out.apply(score_row, axis=1)
    signals, confs = zip(*out["score"].apply(decide))
    out["signal"], out["confidence"] = signals, confs
    return out

def latest_signal(df: pd.DataFrame) -> dict:
    usable = df.dropna().iloc[-1]
    return {
        "close": float(usable["close"]),
        "signal": usable["signal"],
        "confidence": int(usable["confidence"]),
        "score": int(usable["score"]),
        "rsi": float(usable["rsi"]),
        "ema20": float(usable["ema20"]),
        "ema50": float(usable["ema50"]),
        "bb_upper": float(usable["bb_upper"]),
        "bb_lower": float(usable["bb_lower"]),
        "macd_line": float(usable["macd_line"]),
        "macd_signal": float(usable["macd_signal"]),
        "stoch_k": float(usable["stoch_k"]),
        "stoch_d": float(usable["stoch_d"]),
    }
