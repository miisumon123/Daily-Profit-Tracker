
import requests
import pandas as pd

BASE = "https://api.binance.com"

def fetch_klines(symbol: str, interval: str, limit: int = 300) -> pd.DataFrame:
    url = f"{BASE}/api/v3/klines"
    params = {"symbol": symbol.upper(), "interval": interval, "limit": min(max(limit, 1), 1000)}
    r = requests.get(url, params=params, timeout=10)
    r.raise_for_status()
    data = r.json()
    cols = [
        "open_time","open","high","low","close","volume",
        "close_time","quote_asset_volume","number_of_trades",
        "taker_buy_base","taker_buy_quote","ignore"
    ]
    df = pd.DataFrame(data, columns=cols)
    numeric_cols = ["open","high","low","close","volume"]
    df[numeric_cols] = df[numeric_cols].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms")
    df["close_time"] = pd.to_datetime(df["close_time"], unit="ms")
    return df[["open_time","open","high","low","close","volume","close_time"]]
