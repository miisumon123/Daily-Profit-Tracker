
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass
class Settings:
    symbol: str = os.getenv("SYMBOL", "BTCUSDT")
    interval: str = os.getenv("INTERVAL", "1m")
    window: int = int(os.getenv("WINDOW", "300"))
    poll_seconds: int = int(os.getenv("POLL_SECONDS", "60"))
    telegram_bot_token: str | None = os.getenv("TELEGRAM_BOT_TOKEN") or None
    telegram_chat_id: str | None = os.getenv("TELEGRAM_CHAT_ID") or None
    webhook_url: str | None = os.getenv("WEBHOOK_URL") or None
