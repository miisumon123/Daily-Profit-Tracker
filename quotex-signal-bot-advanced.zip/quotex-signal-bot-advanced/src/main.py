
import time
from datetime import datetime, timezone
from apscheduler.schedulers.background import BackgroundScheduler

from .config import Settings
from .data_providers.binance import fetch_klines
from .strategies.advanced import build_features, latest_signal
from .notifiers.telegram import send_telegram
from .notifiers.webhook import post_webhook

settings = Settings()
scheduler = BackgroundScheduler(timezone="UTC")

def tick():
    try:
        df = fetch_klines(settings.symbol, settings.interval, settings.window)
        df.set_index("close_time", inplace=True)
        feats = build_features(df)
        sig = latest_signal(feats)
        sig["symbol"] = settings.symbol
        sig["interval"] = settings.interval
        sig["ts"] = datetime.now(timezone.utc).isoformat()

        line = (
            f"[{sig['symbol']} {sig['interval']}] {sig['signal']} ({sig['confidence']}%) "
            f"| Close={sig['close']:.2f} | RSI={sig['rsi']:.1f} | Score={sig['score']} "
            f"| MACDΔ={(sig['macd_line']-sig['macd_signal']):.5f} | StochK={sig['stoch_k']:.1f}"
        )
        print(line, flush=True)

        if settings.telegram_bot_token and settings.telegram_chat_id:
            send_telegram(settings.telegram_bot_token, settings.telegram_chat_id, line)
        if settings.webhook_url:
            post_webhook(settings.webhook_url, sig)

    except Exception as e:
        print("Error:", e, flush=True)

def main():
    print(f"Starting signal bot for {settings.symbol} @ {settings.interval} (poll {settings.poll_seconds}s)")
    tick()
    scheduler.add_job(tick, "interval", seconds=settings.poll_seconds, id="poll")
    scheduler.start()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        scheduler.shutdown()

if __name__ == "__main__":
    main()
