
import requests

def post_webhook(url: str | None, payload: dict) -> None:
    if not url:
        return
    try:
        requests.post(url, json=payload, timeout=10)
    except Exception:
        pass
