
# Qurtex / Quotex Signal Bot — Advanced (RSI, EMA, Bollinger, MACD, Stoch RSI)

> Educational project: generates **CALL / PUT / NO_TRADE** signals from multiple indicators
> using public market data (e.g. Binance). Designed for **manual execution** on Qurtex/Quotex
> (no autotrading).

## What's New vs Basic
- Adds **MACD (12,26,9)** and **Stochastic RSI (14,3,3)**.
- **5-vote scoring** (RSI, EMA, Bollinger, MACD, StochRSI). Signals only when **≥3** agree.
- Confidence scaled by votes (0–100).

## Quick Start
```bash
git clone https://github.com/yourname/quotex-signal-bot-advanced.git
cd quotex-signal-bot-advanced
python -m venv .venv && source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# edit .env (SYMBOL, INTERVAL, POLL_SECONDS, optional Telegram/webhook)
python -m src.main
```

## .env
```env
SYMBOL=BTCUSDT
INTERVAL=1m
WINDOW=300
POLL_SECONDS=60
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
WEBHOOK_URL=
```

## Strategy (5 votes)
- **RSI(14)**: <30 → +1 CALL, >70 → -1 PUT
- **EMA(20/50)**: 20>50 → +1, 20<50 → -1
- **Bollinger(20,2σ)**: Close ≤ Lower → +1, Close ≥ Upper → -1
- **MACD(12,26,9)**: MACD > Signal → +1, < → -1
- **Stoch RSI(14,3,3)**: K < 20 → +1, K > 80 → -1

**Decision**
- Score ≥ +3 → `CALL`
- Score ≤ -3 → `PUT`
- else → `NO_TRADE`
- Confidence = |score| / 5 × 100

## Notes
- Uses Binance public API for candles (no key).
- Works for symbols Qurtex lists (e.g. BTCUSDT, EURUSDT, XAUUSDT) with similar pricing.
- For **manual** trading only. No financial advice. Use at your own risk.
